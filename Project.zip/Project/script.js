document.addEventListener("DOMContentLoaded", function() {
    
    // Fetch the JSON data
    fetch("https://cdn.shopify.com/s/files/1/0564/3685/0790/files/singleProduct.json?v=1701948448")
    .then(response => response.json())
    .then(data => {
        // Access the JSON data and render it
        renderJSON(data);
    })
    .catch(error => console.log(error));

    // Function to render JSON content
    function renderJSON(data) {
        const contentCartDiv = document.querySelector(".content");
        const imageContainerDiv = document.getElementById("imageContainer");

        contentCartDiv.innerHTML = "";
        imageContainerDiv.innerHTML = "";

        // Append product details to the content div
        contentCartDiv.appendChild(createVendorElement(data.product.vendor));
        contentCartDiv.appendChild(createTitleElement(data.product.title));
        contentCartDiv.appendChild(createHorizontalLine());
        appendPriceDiscount(data, contentCartDiv);
        contentCartDiv.appendChild(createHorizontalLine())
        appendColorOptionsAsButtons(data, contentCartDiv);
        contentCartDiv.appendChild(createHorizontalLine())
        appendSizeOptions(data, contentCartDiv);
        
        // Create a container div for itemControlDiv and "Add to Cart" button
        const controlsContainer = document.createElement("div");
        controlsContainer.style.display = "flex";
        controlsContainer.style.alignItems = "center";

        // Append itemControlDiv to controlsContainer
        const itemControlDiv = document.createElement("div");
        itemControlDiv.classList.add("item-control");
        itemControlDiv.style.width = "169px";
        itemControlDiv.style.height = "59px";
        itemControlDiv.style.borderRadius = "29.5px";
        itemControlDiv.style.backgroundColor = '#F3F3F3';
        itemControlDiv.style.display = "flex";
        itemControlDiv.style.margin='15px 15px 0px 0px';
        itemControlDiv.style.alignItems = "center";
        itemControlDiv.style.justifyContent = "space-around"; // Center the buttons
        appendItemControlButtons(itemControlDiv);
        controlsContainer.appendChild(itemControlDiv);
        
        // Create and append "Add to Cart" button
        const addToCartButton = createAddToCartButton(data.product.title); // Pass product title as argument
        controlsContainer.appendChild(addToCartButton);
        contentCartDiv.appendChild(controlsContainer);
        
        // Create a container for displaying selected product details
        const selectedProductContainer = document.createElement("div");
        //selectedProductContainer.style.height="25px";
        selectedProductContainer.id = "selectedProductContainer";
        contentCartDiv.appendChild(selectedProductContainer);
        
        contentCartDiv.appendChild(createHorizontalLine())
        contentCartDiv.appendChild(createDescriptionElement(data.product.description));
        var srci="./assets/Rectangle 4.png"
        imageContainerDiv.appendChild(createImageElement(srci));
    }
    function appendItemControlButtons(container) {
        const decrementBtn = document.createElement("button");
        decrementBtn.textContent = "-";
        decrementBtn.style.border="none";
        decrementBtn.style.size="10px";
        decrementBtn.style.fontSize="20px";
        decrementBtn.addEventListener("click", decrementItem);

        const itemCount = document.createElement("span");
        itemCount.textContent = "0";
        itemCount.style.fontSize="20px";
        itemCount.classList.add("item-count");

        const incrementBtn = document.createElement("button");
        incrementBtn.textContent = "+";
        incrementBtn.style.border="none";
        incrementBtn.style.size="18px";
        incrementBtn.style.fontSize="20px";
        incrementBtn.addEventListener("click", incrementItem);

        container.appendChild(decrementBtn);
        container.appendChild(itemCount);
        container.appendChild(incrementBtn);
    }

    function decrementItem() {
        const itemCount = document.querySelector(".item-count");
        let count = parseInt(itemCount.textContent);
        if (count > 0) {
            count--;
            itemCount.textContent = count;
        }
    }

    function incrementItem() {
        const itemCount = document.querySelector(".item-count");
        let count = parseInt(itemCount.textContent);
        count++;
        itemCount.textContent = count;
    }

    function addToCart(productTitle) {
        const selectedProductContainer = document.getElementById("selectedProductContainer");
    
        // Find the selected color
        const selectedColor = document.querySelector('input[name="color"]:checked');
        const colorValue = selectedColor ? selectedColor.value : "No color selected";
    
        // Find the selected size
        const selectedSize = document.querySelector('input[name="size"]:checked');
        const sizeValue = selectedSize ? selectedSize.value : "No size selected";
    
        // Clear previous messages
        selectedProductContainer.innerHTML = "";
    
        // Create and append the new message
        const selectedProductDetails = document.createElement("p");
        selectedProductDetails.style.fontSize="14px"
        selectedProductContainer.style.backgroundColor = "#E7F8B7";
        selectedProductContainer.style.padding = "15px";
        selectedProductContainer.style.borderRadius="17px";
        selectedProductDetails.style.marginBlockStart="0rem";
        selectedProductDetails.style.marginBlockEnd="0rem";
        selectedProductDetails.textContent = `${productTitle} with color ${colorValue} and size ${sizeValue} added to the cart`;
        
        selectedProductContainer.appendChild(selectedProductDetails);
        // You can add your logic to add the item to the cart here
    }
    
    // function addToCart(productTitle) {
    //     const selectedProductContainer = document.getElementById("selectedProductContainer");
    
    //     // Find the selected color
    //     const selectedColor = document.querySelector('input[name="color"]:checked');
    //     const colorValue = selectedColor ? selectedColor.value : "No color selected";
    
    //     // Find the selected size
    //     const selectedSize = document.querySelector('input[name="size"]:checked');
    //     const sizeValue = selectedSize ? selectedSize.value : "No size selected";
    
    //     const selectedProductDetails = document.createElement("p");
    //     selectedProductContainer.style.backgroundColor = "#E7F8B7";
    //     selectedProductContainer.style.padding = "3px";
    //     selectedProductDetails.textContent = `${productTitle} with color ${colorValue} and size ${sizeValue} added to the cart`;
    //     selectedProductContainer.appendChild(selectedProductDetails);
    //     // You can add your logic to add the item to the cart here
    // }
    

    
    // Function to create "Add to Cart" button
    function createAddToCartButton(productTitle) {
        const addToCartButton = document.createElement("button");
        addToCartButton.textContent = "Add to Cart";
        addToCartButton.style.fontWeight = "700";
        addToCartButton.style.fontSize = "18px";
        addToCartButton.style.lineHeight = "21.78px";
        addToCartButton.style.width="350px";
        addToCartButton.style.border = "none"; // Remove border
        addToCartButton.style.backgroundColor = "#3A4980"; // Set background color
        addToCartButton.style.color = "#FFFFFF"; // Set text color
        addToCartButton.style.padding = "10px 20px"; // Add padding
        addToCartButton.style.borderRadius = "29.5px"; 
        addToCartButton.style.margin="35px 17px 20px";
        addToCartButton.addEventListener("click", () => addToCart(productTitle)); // Add click event listener
        return addToCartButton;
    }
    
    function createVendorElement(vendor) {
        const vendorElement = document.createElement("p");
        vendorElement.textContent = vendor;
        vendorElement.style.color = "grey";
        vendorElement.style.margin="5px"
        return vendorElement;
    }

    function createTitleElement(title) {
        const titleElement = document.createElement("h2");
        titleElement.textContent = title;
        titleElement.style.margin = "5px 0px 5px 0px";
        return titleElement;
    }

    function createHorizontalLine() {
        const line = document.createElement("hr");
        line.style.backgroundColor = "#E4E4E4";
        line.style.height="1px";
        line.style.width="582px"
        line.style.border="none";
        return line;
    }

    function appendPriceDiscount(data, container) {
        const priceDiscountContainer = document.createElement("div");
        priceDiscountContainer.style.display = "flex";
        priceDiscountContainer.style.alignItems = "center";
        container.appendChild(priceDiscountContainer);

        const priceElement = document.createElement("h1");
        priceElement.textContent = `${data.product.price}.00`;
        priceElement.style.color = "#25549E";
        priceElement.style.margin = "1px";
        priceDiscountContainer.appendChild(priceElement);

        const spanElement = document.createElement("span");
        spanElement.textContent = "35% Off";
        spanElement.style.marginLeft = "10px";
        spanElement.style.color = "#E75F55";
        spanElement.style.fontSize = "20px";
        priceDiscountContainer.appendChild(spanElement);

        const delElement = document.createElement("del");
        const originalPriceElement = document.createElement("p");
        originalPriceElement.textContent = `${data.product.compare_at_price}.00`;
        originalPriceElement.style.margin="5px 0px 10px "
        originalPriceElement.style.color = "grey";
        delElement.appendChild(originalPriceElement);
        container.appendChild(delElement);
    }

    function appendColorOptionsAsButtons(data, container) {
        const colorChoiceParagraph = document.createElement("p");
        colorChoiceParagraph.textContent = "Choose a Color";
        colorChoiceParagraph.style.margin="16px 0px 2px 0px"
        colorChoiceParagraph.style.color = "grey";
        container.appendChild(colorChoiceParagraph);
    
        let lastSelectedButton = null;
        data.product.options[0].values.forEach(colorOption => {
            const colorRadioContainer = document.createElement("label");
            colorRadioContainer.style.position = "relative"; // Needed to position the tick symbol correctly
            colorRadioContainer.style.display = "inline-block";
            colorRadioContainer.style.width = '50px';
            colorRadioContainer.style.height = '50px';
            colorRadioContainer.style.margin = '5px';
            colorRadioContainer.style.border = '2px solid transparent'; // Default no visible border
            colorRadioContainer.style.padding = '3px'; // Padding to keep space for the border
    
            const colorRadio = document.createElement("input");
            colorRadio.type = "radio";
            colorRadio.name = "color";
            colorRadio.value = Object.keys(colorOption)[0];
            colorRadio.style.width = '100%';
            colorRadio.style.height = '100%';
            colorRadio.style.opacity = "0"; // Hide the radio input itself
            colorRadio.style.cursor = "pointer";
    
            const colorRadioTick = document.createElement("span");
            colorRadioTick.style.position = "absolute";
            colorRadioTick.style.top = "3px";
            colorRadioTick.style.left = "3px";
            colorRadioTick.style.right = "3px";
            colorRadioTick.style.bottom = "3px";
            colorRadioTick.style.borderRadius = "0%"; 
            colorRadioTick.style.background = Object.values(colorOption)[0];
            colorRadioTick.style.display = "flex";
            colorRadioTick.style.alignItems = "center";
            colorRadioTick.style.justifyContent = "center";
    
            // Add tick icon using CSS
            const tickIcon = document.createElement("span");
            tickIcon.textContent = "✓";
            tickIcon.style.color = "#FFFFFF";
            tickIcon.style.fontSize = "24px";
            tickIcon.style.display = "none"; // Initially hidden
    
            colorRadio.onclick = function() {
                // Get the color from the background of colorRadioTick
                let currentColor = colorRadioTick.style.background;
            
                if (lastSelectedButton) {
                    lastSelectedButton.style.border = '2px solid transparent'; // Reset previous button
                    lastSelectedButton.children[1].children[0].style.display = "none"; // Hide tick of previously selected button
                }
                
                // Set the border color of the current radio container to the color of the selected button
                colorRadioContainer.style.border = `2px solid ${currentColor}`; // Highlight the selected button with the same color
                tickIcon.style.display = "flex"; // Show tick on selected button
                lastSelectedButton = colorRadioContainer; // Update lastSelectedButton to current container
            };
            
    
            colorRadioContainer.appendChild(colorRadio);
            colorRadioContainer.appendChild(colorRadioTick);
            colorRadioTick.appendChild(tickIcon);
            container.appendChild(colorRadioContainer);
        });
    }
    
    
    function appendSizeOptions(data, container) {
        data.product.options.forEach(option => {
            if (option.name.toLowerCase() !== "color") {
                const optionLabel = document.createElement("p");
                optionLabel.textContent = `Choose a ${option.name}`;
                optionLabel.style.color = "grey";
                container.appendChild(optionLabel);
    
                option.values.forEach(value => {
                    const sizeRadio = document.createElement("input");
                    sizeRadio.type = "radio";
                    sizeRadio.name = "size";
                    sizeRadio.value = value;
                    sizeRadio.style.margin = "5px";
    
                    const radioLabel = document.createElement("label");
                    radioLabel.textContent = value;
                    radioLabel.style.color = "black";
                    radioLabel.style.margin = "5px";
    
                    const radioContainer = document.createElement("span");
                    radioContainer.style.backgroundColor = "#EDF0F8"; // Gray background color
                    radioContainer.style.padding = "5px";
                    radioContainer.style.borderRadius = "5px";
                    radioContainer.style.margin = "5px"; 
                    radioContainer.style.width='16px';
                    radioContainer.style.height='16px'// Add margin between radio button groups
                    radioContainer.appendChild(sizeRadio);
                    radioContainer.appendChild(radioLabel);
                    container.appendChild(radioContainer);
                });
            }
        });
    }
    
    function createDescriptionElement(description) {
        const descriptionElement = document.createElement("div");
        descriptionElement.innerHTML = description;
        descriptionElement.style.color='#A3A3A3';
        descriptionElement.style.size='20px';
        descriptionElement.style.fontWeight='300';
        descriptionElement.style.lineHeight='28px';        
        return descriptionElement;
    }

    function createImageElement(src) {
        const Outer=document.createElement("div")
        const imageDiv1 = document.createElement("div");
        const imageDiv2=document.createElement("div");
        
        const imageEle=document.createElement('img');
        imageDiv1.style.margin="45px 50px 0px 50px";
        imageDiv1.style.borderRadius="10px";
        imageEle.src = src;
        imageEle.style.margin="20px 20px 15px 20px";
        imageEle.style.height='400px';
        imageDiv1.appendChild(imageEle);
        Outer.appendChild(imageDiv1);
        
        // Create a container for additional images using flex
        imageDiv2.style.display = "flex";
        imageDiv2.style.justifyContent = "space-between"; // Space evenly
        imageDiv2.style.marginTop = "20px"; // Add margin between images
        
        // Append additional images
        for (let i = 4; i < 8; i++) {
            const additionalImage = document.createElement("img");
            additionalImage.src = "./assets/Rectangle "+i+".png"; // Use the same source for simplicity, you can replace it with different sources
            additionalImage.style.width = "100px"; 
            additionalImage.style.margin="10px";
            additionalImage.style.marginBottom='20px';// Set width of each image
            additionalImage.style.height = "100px"; // Set height of each image
            imageDiv2.appendChild(additionalImage);
        }
        
        Outer.appendChild(imageDiv2);
        return Outer;
    }
});